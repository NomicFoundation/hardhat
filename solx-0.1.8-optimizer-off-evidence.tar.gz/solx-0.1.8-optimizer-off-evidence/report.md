# solx test-execution evaluation — running matrix

solx pin: 0.1.8. Legend: P/F/S = passing/failing/skipped.

## Tests executed under the subject compiler

One row per repository-and-runner. Both compiler pairs run the same suite there, so it is counted once rather than once per pair; skipped tests are excluded. A row is controlled when at least one of its pairs had a same-pipeline control that actually ran the suite — a row that is not controlled establishes the test universe under the subject compiler only. Pairs whose control turns the optimizer off are a different pipeline and are not counted here.

| repository | runner | tests under subject | controlled |
|---|---|--:|---|
| solady-solx | solidity | 2041 | yes |
| aave-v4-solx | solidity | 1559 | yes |
| uniswap-v4-core-solx | solidity | 598 | yes |
| graph-horizon-solx | solidity | 574 | yes |
| openzeppelin-contracts-0.34 | solidity | 347 | yes |
| 1inch-swap-vm-solx | solidity | 0 | yes |
| **total** | | **5119** | **5119 controlled** |

## Matrix

| scenario | runner | pair | verdict | solx | control | solx-only | both | EIP-170 | flaky |
|---|---|---|---|---|---|--:|--:|--:|--:|
| 1inch-aqua-solx | solidity | solx-0.1.8 vs solc-no-opt | **pass** | 49P/0F/0S | 49P/0F/0S | 0 | 0 | 0 | 0 |
| 1inch-swap-vm-solx | solidity | solx-0.1.8-via-ir vs solc-via-ir | **cannot-compile** | no summary (exit 1) | 706P/0F/0S | 0 | 0 | 0 | 0 |
| 1inch-swap-vm-solx | solidity | solx-0.1.8 vs default | **cannot-compile** | no summary (exit 1) | no summary (exit 1) | 0 | 0 | 0 | 0 |
| aave-v4-solx | solidity | solx-0.1.8-via-ir vs solc-via-ir | **control-cannot-compile** | 1559P/0F/1S | no summary (exit 1) | 0 | 0 | 0 | 0 |
| aave-v4-solx | solidity | solx-0.1.8 vs default | **pass** | 1559P/0F/1S | 1559P/0F/1S | 0 | 0 | 0 | 0 |
| ens-verifiable-factory-solx | solidity | solx-0.1.8 vs solc-no-opt | **pass** | 23P/0F/0S | 23P/0F/0S | 0 | 0 | 0 | 0 |
| graph-horizon-solx | solidity | solx-0.1.8-via-ir vs solc-via-ir | **pass** | 574P/0F/2S | 574P/0F/2S | 0 | 0 | 0 | 0 |
| graph-horizon-solx | solidity | solx-0.1.8 vs default | **pass** | 574P/0F/2S | 574P/0F/2S | 0 | 0 | 0 | 0 |
| openzeppelin-contracts-0.34 | solidity | solx-0.1.8-via-ir vs solc-via-ir | **pass** | 347P/0F/0S | 346P/1F/0S | 0 | 0 | 0 | 0 |
| openzeppelin-contracts-0.34 | solidity | solx-0.1.8 vs default | **pass** | 347P/0F/0S | 347P/0F/0S | 0 | 0 | 0 | 0 |
| solady-solx | solidity | solx-0.1.8-via-ir vs solc-via-ir | **pass** | 2040P/1F/0S | 2040P/1F/0S | 0 | 1 | 0 | 0 |
| solady-solx | solidity | solx-0.1.8 vs default | **pass** | 2040P/1F/0S | 2040P/1F/0S | 0 | 1 | 0 | 0 |
| uniswap-v4-core-solx | solidity | solx-0.1.8-via-ir vs solc-via-ir | **pass** | 598P/0F/0S | 598P/0F/0S | 0 | 0 | 0 | 0 |
| uniswap-v4-core-solx | solidity | solx-0.1.8 vs default | **pass** | 598P/0F/0S | 598P/0F/0S | 0 | 0 | 0 | 0 |

## Deployed bytecode sizes (EIP-170 limit 24576 B)

Scoped to non-test sources compiled at solc 0.8.34. Contracts from a repo's test tree are deployed by the Solidity test runner with the code-size limit lifted, so they are exempt from the limit and are shown in their own column rather than counted as over-limit. Artifacts from other solc versions a repo also compiles (lidofinance-core builds six) are excluded entirely: neither compiler under comparison produced them. Sizes are read off the artifacts, not the warning text. A cell reads `unattributed` when the run wrote no build-info at solc 0.8.34 to scope by. Mocks and generated test-support contracts that live in source trees rather than a test tree are still counted (openzeppelin's contracts-exposed wrappers, graph-horizon's and lidofinance-core's contracts/mocks): the limit does apply to them. Read a row as a statement about everything the repo compiles, not about its public library surface.

| scenario | runner | pair | solx max | solx over | control max | control over | largest under solx | solx test-harness max (exempt) |
|---|---|---|--:|--:|--:|--:|---|--:|
| 1inch-aqua-solx | solidity | solx-0.1.8 vs solc-no-opt | 3690 B | 0 | 7429 B | 0 | src/AquaRouter.sol:AquaRouter | 27752 B |
| 1inch-swap-vm-solx | solidity | solx-0.1.8-via-ir vs solc-via-ir | unattributed | unattributed | 36743 B | 5 | unattributed | unattributed |
| 1inch-swap-vm-solx | solidity | solx-0.1.8 vs default | unattributed | unattributed | unattributed | unattributed | unattributed | unattributed |
| aave-v4-solx | solidity | solx-0.1.8-via-ir vs solc-via-ir | 27809 B | 1 | unattributed | unattributed | src/spoke/instances/SpokeInstance.sol:SpokeInstance | 243306 B |
| aave-v4-solx | solidity | solx-0.1.8 vs default | 27809 B | 1 | 24291 B | 0 | src/spoke/instances/SpokeInstance.sol:SpokeInstance | 210587 B |
| ens-verifiable-factory-solx | solidity | solx-0.1.8 vs solc-no-opt | 3063 B | 0 | 5934 B | 0 | src/mock/MockRegistryV2.sol:MockRegistryV2 | 31087 B |
| graph-horizon-solx | solidity | solx-0.1.8-via-ir vs solc-via-ir | 27696 B | 2 | 22199 B | 0 | contracts/payments/collectors/RecurringCollector.sol:RecurringCollector | 145735 B |
| graph-horizon-solx | solidity | solx-0.1.8 vs default | 27025 B | 1 | 24007 B | 0 | contracts/payments/collectors/RecurringCollector.sol:RecurringCollector | 124000 B |
| openzeppelin-contracts-0.34 | solidity | solx-0.1.8-via-ir vs solc-via-ir | 30054 B | 9 | 21506 B | 0 | contracts-exposed/contracts/mocks/governance/GovernorStorageMock.sol:$GovernorStorageMock | 48970 B |
| openzeppelin-contracts-0.34 | solidity | solx-0.1.8 vs default | 28744 B | 4 | 25277 B | 1 | contracts-exposed/contracts/utils/Packing.sol:$Packing | 41862 B |
| solady-solx | solidity | solx-0.1.8-via-ir vs solc-via-ir | 4953 B | 0 | 4133 B | 0 | src/utils/ext/zksync/ERC1967Factory.sol:ERC1967Factory | 105711 B |
| solady-solx | solidity | solx-0.1.8 vs default | 5059 B | 0 | 4561 B | 0 | src/accounts/Timelock.sol:Timelock | 93494 B |
| uniswap-v4-core-solx | solidity | solx-0.1.8-via-ir vs solc-via-ir | 23953 B | 0 | 24009 B | 0 | src/PoolManager.sol:PoolManager | 181973 B |
| uniswap-v4-core-solx | solidity | solx-0.1.8 vs default | 23230 B | 0 | 26947 B | 1 | src/PoolManager.sol:PoolManager | 156612 B |

## solc optimizer-off calibration

Both sides are solc: the subject profile against the same compiler with its optimizer turned off. Nothing here is a statement about solx — it measures how much solc's own optimizer toggle perturbs test outcomes, which is the scale a solx-vs-solc differential has to be read against. These rows never enter the headline. `fail only with opt` are tests that fail under the subject profile and not without the optimizer; `fail only without opt` is the reverse. A `no-opt compiles` of NO is a result in its own right: the control could not be built, and the column carries the compiler's own words.

| scenario | runner | pair | no-opt compiles | subject P/F/S | no-opt P/F/S | fail only with opt | fail only without opt | verdict |
|---|---|---|---|---|---|--:|--:|---|
| 1inch-aqua-solx | solidity | default vs solc-no-opt | yes | 49P/0F/0S | 49P/0F/0S | 0 | 0 | **pass** |
| 1inch-aqua-solx | solidity | solc-via-ir vs solc-via-ir-no-opt | yes | 49P/0F/0S | 49P/0F/0S | 0 | 0 | **pass** |
| 1inch-swap-vm-solx | solidity | solc-via-ir vs solc-via-ir-no-opt | NO — exit 1: Error HHE910: Compilation failed | 706P/0F/0S | no summary (exit 1) | 0 | 0 | **control-cannot-compile** |
| aave-v4-solx | solidity | default vs solc-no-opt | yes | 1559P/0F/1S | 1559P/0F/1S | 0 | 0 | **pass** |
| aave-v4-solx | solidity | solc-via-ir vs solc-via-ir-no-opt | test-source build fails before any test runs | no summary (exit 1) | no summary (exit 1) | 0 | 0 | **cannot-compile** |
| ens-verifiable-factory-solx | solidity | default vs solc-no-opt | yes | 23P/0F/0S | 23P/0F/0S | 0 | 0 | **pass** |
| ens-verifiable-factory-solx | solidity | solc-via-ir vs solc-via-ir-no-opt | yes | 23P/0F/0S | 23P/0F/0S | 0 | 0 | **pass** |
| graph-horizon-solx | solidity | default vs solc-no-opt | yes | 574P/0F/2S | 574P/0F/2S | 0 | 0 | **pass** |
| graph-horizon-solx | solidity | solc-via-ir vs solc-via-ir-no-opt | yes | 574P/0F/2S | 574P/0F/2S | 0 | 0 | **pass** |
| openzeppelin-contracts-0.34 | solidity | default vs solc-no-opt | NO — exit 1: CompilerError: Stack too deep. Try compiling with `--via-ir` (cli) or the equivalent `viaIR: true` (standard JSON) while enabling the optimizer. Otherwise, try removing local variables. | 347P/0F/0S | no summary (exit 1) | 0 | 0 | **control-cannot-compile** |
| openzeppelin-contracts-0.34 | solidity | solc-via-ir vs solc-via-ir-no-opt | yes | 346P/1F/0S | 347P/0F/0S | 1 | 0 | **test-failures** |
| solady-solx | solidity | default vs solc-no-opt | NO — exit 1: CompilerError: Stack too deep. Try compiling with `--via-ir` (cli) or the equivalent `viaIR: true` (standard JSON) while enabling the optimizer. Otherwise, try removing local variables. When compiling inline assembly: Variable key_ is 2 slot(s) too deep inside the stack. Stack too deep. Try compilin | 2040P/1F/0S | no summary (exit 1) | 1 | 0 | **control-cannot-compile** |
| solady-solx | solidity | solc-via-ir vs solc-via-ir-no-opt | yes | 2040P/1F/0S | 2038P/3F/0S | 0 | 2 | **pass** |
| uniswap-v4-core-solx | solidity | default vs solc-no-opt | yes | 598P/0F/0S | 598P/0F/0S | 0 | 0 | **pass** |
| uniswap-v4-core-solx | solidity | solc-via-ir vs solc-via-ir-no-opt | yes | 598P/0F/0S | 598P/0F/0S | 0 | 0 | **pass** |

## Details

### 1inch-swap-vm-solx / solidity / solx-0.1.8-via-ir-vs-solc-via-ir

test-source build fails before any test runs


bytecode/artifact inventory differences:

- 167 artifact(s) the control produced and solx did not: src/SwapVM.sol:SwapVM, src/instructions/Balances.sol:Balances, src/instructions/Balances.sol:BalancesArgsBuilder, src/instructions/BaseFeeAdjuster.sol:BaseFeeAdjuster, src/instructions/BaseFeeAdjuster.sol:BaseFeeAdjusterArgsBuilder, src/instructions/Controls.sol:Controls, src/instructions/Controls.sol:ControlsArgsBuilder, src/instructions/Debug.sol:Debug, src/instructions/Decay.sol:Decay, src/instructions/Decay.sol:DecayArgsBuilder, src/instructions/Decay.sol:DecayingOffsetLib, src/instructions/DutchAuction.sol:DutchAuction, src/instructions/DutchAuction.sol:DutchAuctionArgsBuilder, src/instructions/Extruction.sol:Extruction, src/instructions/Extruction.sol:IExtruction, src/instructions/Extruction.sol:IStaticExtruction, src/instructions/Fee.sol:Fee, src/instructions/Fee.sol:FeeArgsBuilder, src/instructions/FeeExperimental.sol:FeeArgsBuilderExperimental, src/instructions/FeeExperimental.sol:FeeExperimental, and 147 more

### 1inch-swap-vm-solx / solidity / solx-0.1.8-vs-default

test-source build fails before any test runs


### aave-v4-solx / solidity / solx-0.1.8-via-ir-vs-solc-via-ir

the solc-via-ir control fails to compile (exit 1): Error HHE910: Compilation failed / For more info go to https://hardhat.org/HHE910 or run Hardhat with --show-stack-traces


bytecode/artifact inventory differences:

- 329 artifact(s) solx produced and the control did not: src/access/AccessManagerEnumerable.sol:AccessManagerEnumerable, src/access/interfaces/IAccessManagerEnumerable.sol:IAccessManagerEnumerable, src/dependencies/chainlink/AggregatorV3Interface.sol:AggregatorV3Interface, src/dependencies/openzeppelin-upgradeable/AccessManagedUpgradeable.sol:AccessManagedUpgradeable, src/dependencies/openzeppelin-upgradeable/ContextUpgradeable.sol:ContextUpgradeable, src/dependencies/openzeppelin-upgradeable/ERC20Upgradeable.sol:ERC20Upgradeable, src/dependencies/openzeppelin-upgradeable/Initializable.sol:Initializable, src/dependencies/openzeppelin/AccessManaged.sol:AccessManaged, src/dependencies/openzeppelin/AccessManager.sol:AccessManager, src/dependencies/openzeppelin/Address.sol:Address, src/dependencies/openzeppelin/Arrays.sol:Arrays, src/dependencies/openzeppelin/AuthorityUtils.sol:AuthorityUtils, src/dependencies/openzeppelin/Bytes.sol:Bytes, src/dependencies/openzeppelin/Comparators.sol:Comparators, src/dependencies/openzeppelin/Context.sol:Context, src/dependencies/openzeppelin/ECDSA.sol:ECDSA, src/dependencies/openzeppelin/ERC1967Proxy.sol:ERC1967Proxy, src/dependencies/openzeppelin/ERC1967Utils.sol:ERC1967Utils, src/dependencies/openzeppelin/ERC20.sol:ERC20, src/dependencies/openzeppelin/EnumerableSet.sol:EnumerableSet, and 309 more

### solady-solx / solidity / solx-0.1.8-via-ir-vs-solc-via-ir

(contains 1 test(s) failing under BOTH compilers, excluded from the solx verdict; 1 of them fail with DIFFERENT text on the two sides)


failing under BOTH compilers (upstream/pin noise, excluded from the solx verdict):

- `BlockHashLibTest#testBlockHash(uint256,uint256,uint256,bytes32)` (DIFFERENT failure text on the two sides — inspect before calling it the same failure)
  - solx: `at BlockHashLibTest.testBlockHash (test/BlockHashLib.t.sol:60)`
  - control: `at BlockHashLibTest.testBlockHash (test/BlockHashLib.t.sol:45)`

### solady-solx / solidity / solx-0.1.8-vs-default

(contains 1 test(s) failing under BOTH compilers, excluded from the solx verdict; 1 of them fail with DIFFERENT text on the two sides)


failing under BOTH compilers (upstream/pin noise, excluded from the solx verdict):

- `BlockHashLibTest#testBlockHash(uint256,uint256,uint256,bytes32)` (DIFFERENT failure text on the two sides — inspect before calling it the same failure)
  - solx: `Warning: runtime bytecode size is 24880B that exceeds the EVM limit of 24576B`
  - control: `Warning: Virtual modifiers are deprecated and scheduled for removal.`