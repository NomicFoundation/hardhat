# solx test-execution evaluation — sweep state

Branch: solx-test-execution-evaluation (worktree /home/workspace/repos/hardhat-solx-helpers).
Clone dir: /tmp/e2e-solx-test-eval (pass --e2e-clone-dir on every run).
Verdaccio: running from this worktree on 4873. 11 packages/*/package.json bumps are
uncommitted on purpose; revert with `git checkout -- packages/*/package.json` at the very end.
Command template:
  node scripts/benchmark/test-under-solx.ts --scenario ./end-to-end/<s> --runner <r> \
    --e2e-clone-dir /tmp/e2e-solx-test-eval --out solx-test-evaluation-evidence
Pairs default to solx-0.1.7:default + solx-0.1.7-via-ir:solc-via-ir. Results land in
results/<slug>.json; report.md + summary.json regenerate after each pair.

## Phase 1 — DONE
- [x] script implemented, reviewed (see scratchpad review), lint + 169 tests green
- [x] ens validation: both pairs PASS (23P/0F each side, provenance green)
- [x] negative provenance test: default:default pair -> invalid-provenance, exit 2
      (evidence: negative-provenance-test/ subdir + ens-validation.console.log)
- [x] commits 46d52a91f (script), b08634a44 (wrapper seed pins + lido gate)

## Phase 2 — sweep (plan §5 order)
- [x] 2. ens solidity (both pairs) — PASS/PASS (done during validation)
- [x] 1. openzeppelin-contracts-0.34 mocha (both pairs) — PASS/PASS (7654P; control-only fail
      under solc-via-ir: "MerkleTree > push > pushing to a full tree reverts")
- [x] 3. openzeppelin-contracts-0.34 solidity (both pairs) — PASS/PASS (347P; control-only fail
      under solc-via-ir: BlockhashTest#testFuzzHistoryBlocks — solc control, not solx)
- [x] 4. 1inch-aqua-solx solidity (both pairs) — PASS/PASS (49P each side, clean)
- [x] 5. graph-horizon-solx solidity (both pairs) — PASS/PASS (574P, 2S each side; memory probe
      CLEAN). GOTCHAS: monorepo needs `pnpm --filter '@graphprotocol/horizon^...' run build:self`
      at the clone root after init; repo relocates artifacts to build/contracts/build-info —
      provenance check now discovers build-info dirs by mtime-guarded walk (fixup 35ae2e6fb,
      squash into commit 1 before push).
- [x] 6. uniswap-v4-core-solx solidity (both pairs) — PASS/PASS (598P each side; the feared
      .forge-snapshots gas assertions did NOT fail — note for report: check how snapshot
      assertions behave under hardhat, likely write-mode)
- [~] 7. 1inch-swap-vm-solx solidity (via-IR pair ONLY) — HEADLINE FINDING, verdict rerun in
      flight (bg bsgcmi240). solx via-IR: LLVM ERROR (Stackification, recursive runLoop) x5 on
      stderr, exit 0, ZERO standard-JSON errors, EMPTY bytecode for all 242 contracts ->
      hardhat "Compiled 149", test runner finds 0 suites, exits 0. Control: 706P. Attributed to
      the solx BINARY by direct replay (triage/1inch-swap-vm/). classify() hardened with
      test-universe-mismatch guard (fixup d62f0fb8a). GOTCHA: scenario needs prime step
      `node ./relax-dep-pragmas.cjs` in the clone after install (@1inch/aqua pins pragma 0.8.30).
- [x] 7b. 1inch-swap-vm verdict corrected: harness-failures (0 vs 706 test universe mismatch)
- [x] 8. solady-solx solidity (both pairs) — PASS/PASS (2040P, 1F shared under BOTH compilers:
      BlockHashLibTest#testBlockHash — upstream/pin noise, excluded from solx verdict)
- [x] 9. aave-v4-solx solidity — via-IR: PASS (solx 1559P/1S; control solc-via-ir CANNOT COMPILE
      the test tree: YulException stack-too-deep — recorded as control-side note). legacy: solx
      cannot-compile (OOM/SIGKILL on direct replay, exit 137; control 1559P). Triage in
      triage/aave-v4/. Memory probe #2 clean.
- [x] 10. lidofinance-core-solx mocha via-IR — PASS (1266P/1S both sides; provenance: 2 subject
      0.8.34 build-infos solx + 5 solc ballast; predicted VaultHub EIP-170 revert did NOT occur)
- [x] lidofinance-vaults-solx: recorded "N/A — see core scenario" in the report

## Phase 3
- [x] solx-test-execution-results.md + solx-test-execution-summary.json committed (dd1f3394d)
- [x] bumps reverted; branch pushed to origin (Wodann fork); NO PR. History rebuilt into 3
      clean commits: cc37ccc8b, 0ed1fed45, dd1f3394d. Verdaccio stopped. SWEEP COMPLETE.

## Phase 4 — post-review publication fixes (2026-08-21)

A three-expert retrospective review of the evaluation returned a minimum list before
publication. Applied as additional commits; no history rewritten.

- [x] C1. Finding 4 rewritten. lido's base config DOES set allowUnlimitedContractSize (two
      places), and the wrapper spreads it through, so NO run had EIP-170 enforced. The real
      finding is the size gap: verified maxima re-counted from all 36 run logs, solx max
      162,624 B (aave via-IR), controls one 24,708 B warning (lido). solady corrected from
      52,128 B to 106,224 B via-IR / 93,988 B legacy, and its controls carry zero warnings.
- [x] C3. Headline recomputed from the 18 per-pair records: 14,111 tests under solx, 12,552 with
      a same-pipeline control. The old ~14,700 counted swap-vm's 706 control-only tests.
      Counting method now stated in the document, with a per-row table.
- [x] C4. Positive control run on ens (positive-control/): a solx-side-only assertion failure is
      detected, named, attributed to solx, and reproduced by the determinism screen; the verdict
      returns to pass when the perturbation is removed. Perturbation patch archived; the clone
      was reverted.
- [x] H3/H4. solady figures corrected. Finding 3 restated as "graph: no signal; aave: not
      tested".
- [x] Limitations section added (18 items), plus the conflict-of-interest line and the
      upstream-status line. Six claims the review ruled unsupportable were checked absent.
- [x] Bottom line restated: scoped to what was executed and controlled, next to the two
      compile-stage failures and the universal EIP-170 overshoot.
- [x] Harness: test-universe guard extended from solxTotal===0 to a <90%-of-control shortfall;
      compileErrorMarker kept on the pair record and named in the verdict detail instead of
      being dropped on green runs. lint:scripts + test:scripts green (169). The 18 sweep rows
      predate this logic; only the positive control ran under it.
- [x] Versions pinned in the document from the clones: hardhat 3.14.0, EDR 0.17.0 (both from the
      public registry via the Verdaccio proxy), hardhat-solx 2.0.0 and hardhat-vendored 3.0.5
      built locally, solx 0.1.7, solc 0.8.34, evm target osaka.
- [x] Evidence archived as solx-test-evaluation-evidence.tar.gz on the branch (all logs
      untruncated; ~0.5 MB compressed) and summary.json regenerated with the compileErrorMarker
      field.
