# 1inch-swap-vm: solx via-IR silently emits an empty build

Finding. solx 0.1.7 cannot compile SwapVM's recursive runLoop via-IR.
It prints "LLVM ERROR: Stackification failed for 'fun_runLoop_62748'" 5 times to stderr.
It then exits 0 with ZERO errors in the standard-JSON response.
Every one of the 242 contracts in the response has empty bytecode.

Attribution. The solx BINARY is at fault, not hardhat-solx. Replaying the exact
build-info input through `.solx/solx-v0.1.7 --standard-json` reproduces it
(see direct-replay-summary.json + swapvm-direct-err.txt).

Downstream effect. Hardhat accepts the response (no errors), reports
"Compiled 149 Solidity files with solx 0.1.7", and writes bytecode-less
artifacts. `hardhat test solidity` then discovers 0 test suites and exits 0
("0 passing"). The solc-via-ir control runs 706 tests. The benchmark's timed
"cold compile solx-0.1.7 via-ir" cell for this scenario is equally hollow:
it measures a compile whose output is empty.

Verdict for the matrix: harness-failures (test universe 0 vs 706), with a
cannot-compile root cause. Not a runtime miscompilation: no wrong code ran.

Repro:
  cd <clone>/1inch-swap-vm-solx
  npx hardhat clean && npx hardhat test solidity --build-profile solx-0.1.7-via-ir
