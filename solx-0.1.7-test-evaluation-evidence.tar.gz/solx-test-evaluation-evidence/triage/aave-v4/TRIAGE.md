# aave-v4: both pairs are asymmetric at the COMPILE stage, in opposite directions

## via-IR pair (solx-0.1.7-via-ir vs solc-via-ir)
solx compiles the FULL tree including the 274-file test suite and runs
1559 tests: ALL PASS (1 skipped), provenance green, 218s.
The solc-via-ir CONTROL cannot compile the test tree at all:
"YulException: Variable var_user is 1 too deep in the stack" then
"Error HHE910: Compilation failed" (723s). This is why the benchmark cells
pass --no-tests. The failure is solc's, not solx's.
Consequence: no solc-via-ir baseline exists for the suite. The legacy pair
below provides the working control instead.

## legacy pair (solx-0.1.7 vs default)
The solc control compiles (the wrapper's two per-file via-IR overrides rescue
Hub/SpokeInstance) and runs the same suite: 1559 PASS, 1 skipped, 331s.
solx's legacy pipeline dies after ~53s: hardhat reports
"Error: Subprocess exited with code null". Replaying the dumped standard-JSON
input through the pinned binary directly exits 137 = SIGKILL: the kernel
OOM-kills solx on this 15.6GB machine (its legacy-pipeline stack-too-deep
spill re-runs full LLVM passes; the scenario notes measured 30+ min wall on
bigger hosts). Verdict: cannot-compile (resource exhaustion), structural.

## Memory probe #2 (vendored OZ Arrays.sol, EVM_DISABLE_MEMORY_SAFE_ASM_CHECK=1)
The via-IR solx run executed all 1559 tests green, so no memory-corruption
signal appeared. Cross-checking the two pairs: 1559 solx-via-IR passes vs
1559 solc-legacy passes — same universe, both fully green.

Repro:
  via-IR control: npx hardhat clean && npx hardhat test solidity --build-profile solc-via-ir
  legacy solx:    npx hardhat clean && EVM_DISABLE_MEMORY_SAFE_ASM_CHECK=1 \
                  npx hardhat compile --build-profile solx-0.1.7
