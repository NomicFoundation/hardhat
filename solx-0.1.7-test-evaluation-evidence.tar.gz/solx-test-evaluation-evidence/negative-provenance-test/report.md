# solx test-execution evaluation — running matrix

solx pin: 0.1.7. Legend: P/F/S = passing/failing/skipped.

| scenario | runner | pair | verdict | solx | control | solx-only | both | EIP-170 | flaky |
|---|---|---|---|---|---|--:|--:|--:|--:|
| ens-verifiable-factory-solx | solidity | default vs default | **invalid-provenance** | 23P/0F/0S | 23P/0F/0S | 0 | 0 | 0 | 0 |

## Details

### ens-verifiable-factory-solx / solidity / default-vs-default

provenance check failed — the run is INVALID, not a solx result: solc-0_8_34-1c149161383683eaa3c250d309bf7896f7ae5bcd.json: solcVersion 0.8.34 has compilerType "solc", expected "solx"; solc-0_8_34-1c149161383683eaa3c250d309bf7896f7ae5bcd.json: solcLongVersion "0.8.34+commit.80d5c536" does not carry the pin 0.1.7
