# solx test-execution evaluation — running matrix

solx pin: 0.1.7. Legend: P/F/S = passing/failing/skipped.

| scenario | runner | pair | verdict | solx | control | solx-only | both | EIP-170 | flaky |
|---|---|---|---|---|---|--:|--:|--:|--:|
| 1inch-aqua-solx | solidity | solx-0.1.7-via-ir vs solc-via-ir | **pass** | 49P/0F/0S | 49P/0F/0S | 0 | 0 | 0 | 0 |
| 1inch-aqua-solx | solidity | solx-0.1.7 vs default | **pass** | 49P/0F/0S | 49P/0F/0S | 0 | 0 | 0 | 0 |
| 1inch-swap-vm-solx | solidity | solx-0.1.7-via-ir vs solc-via-ir | **harness-failures** | 0P/0F/0S | 706P/0F/0S | 0 | 0 | 0 | 0 |
| aave-v4-solx | solidity | solx-0.1.7-via-ir vs solc-via-ir | **pass** | 1559P/0F/1S | no summary (exit 1) | 0 | 0 | 0 | 0 |
| aave-v4-solx | solidity | solx-0.1.7 vs default | **cannot-compile** | no summary (exit 1) | 1559P/0F/1S | 0 | 0 | 0 | 0 |
| ens-verifiable-factory-solx | solidity | solx-0.1.7-via-ir vs solc-via-ir | **pass** | 23P/0F/0S | 23P/0F/0S | 0 | 0 | 0 | 0 |
| ens-verifiable-factory-solx | solidity | solx-0.1.7 vs default | **pass** | 23P/0F/0S | 23P/0F/0S | 0 | 0 | 0 | 0 |
| graph-horizon-solx | solidity | solx-0.1.7-via-ir vs solc-via-ir | **pass** | 574P/0F/2S | 574P/0F/2S | 0 | 0 | 0 | 0 |
| graph-horizon-solx | solidity | solx-0.1.7 vs default | **pass** | 574P/0F/2S | 574P/0F/2S | 0 | 0 | 0 | 0 |
| lidofinance-core-solx | mocha | solx-0.1.7-via-ir vs solc-via-ir | **pass** | 1266P/0F/1S | 1266P/0F/1S | 0 | 0 | 0 | 0 |
| openzeppelin-contracts-0.34 | mocha | solx-0.1.7-via-ir vs solc-via-ir | **pass** | 7654P/0F/1S | 7653P/1F/1S | 0 | 0 | 0 | 0 |
| openzeppelin-contracts-0.34 | mocha | solx-0.1.7 vs default | **pass** | 7654P/0F/1S | 7654P/0F/1S | 0 | 0 | 0 | 0 |
| openzeppelin-contracts-0.34 | solidity | solx-0.1.7-via-ir vs solc-via-ir | **pass** | 347P/0F/0S | 346P/1F/0S | 0 | 0 | 0 | 0 |
| openzeppelin-contracts-0.34 | solidity | solx-0.1.7 vs default | **pass** | 347P/0F/0S | 347P/0F/0S | 0 | 0 | 0 | 0 |
| solady-solx | solidity | solx-0.1.7-via-ir vs solc-via-ir | **pass** | 2040P/1F/0S | 2040P/1F/0S | 0 | 1 | 0 | 0 |
| solady-solx | solidity | solx-0.1.7 vs default | **pass** | 2040P/1F/0S | 2040P/1F/0S | 0 | 1 | 0 | 0 |
| uniswap-v4-core-solx | solidity | solx-0.1.7-via-ir vs solc-via-ir | **pass** | 598P/0F/0S | 598P/0F/0S | 0 | 0 | 0 | 0 |
| uniswap-v4-core-solx | solidity | solx-0.1.7 vs default | **pass** | 598P/0F/0S | 598P/0F/0S | 0 | 0 | 0 | 0 |

## Details

### 1inch-swap-vm-solx / solidity / solx-0.1.7-via-ir-vs-solc-via-ir

test universe mismatch: 0 tests executed under solx vs 706 under the control — a side that silently runs nothing is not comparable (check the build log for swallowed compiler errors)


### aave-v4-solx / solidity / solx-0.1.7-vs-default

test-source build fails before any test runs
