# Positive control — can this setup see a solx-side-only test failure?

Run on 2026-08-21, after the sweep. The sweep found zero solx-only failures. That result is
only worth reading if the setup can report one. This is the check.

## What was perturbed

Scenario: ens-verifiable-factory, solidity runner, pair `solx-0.1.7` vs `default`.

One test function was added to `test/UUPSProxy.t.sol` (see `perturbation.patch`):

    function test_PositiveControl_SolcRuntimeLength() public view {
        assertEq(address(proxy).code.length, 1223);
    }

1223 B is the runtime code length solc 0.8.34 emits for `UUPSProxy` under the `default`
profile. solx 0.1.7 emits 1244 B for the same source. Both figures were read from
`artifacts/src/UUPSProxy.sol/UUPSProxy.json` after a clean compile with each profile.

So the assertion holds on the control side and fails on the solx side. That is the shape of a
solx-only failure. The perturbation is artificial: it detects a compiler difference, not a
miscompilation. What it exercises is the detection path, end to end.

## Result — perturbed run (`perturbed/`)

    verdict test-failures — 1 test(s) fail under solx but pass under the solc control

    | scenario | runner | pair | verdict | solx | control | solx-only |
    | ens-verifiable-factory-solx | solidity | solx-0.1.7 vs default | test-failures | 23P/1F/0S | 24P/0F/0S | 1 |

    solx-only failures:
    - `UUPSProxyTest#test_PositiveControl_SolcRuntimeLength()` (reproduced)

Every stage behaved:

- the solx side went red with `assertion failed: 1244 != 1223`; the control side stayed green
- the failure identifier was parsed, and the set-difference put it in `solxOnlyFailures`
- the verdict flipped from `pass` to `test-failures`
- provenance stayed green on both sides, so the flip is not a provenance artifact
- the determinism screen fired for the first time in this evaluation, re-ran the named test
  under `--grep`, and recorded `reproduced`

## Result — restored run (`restored/`)

    verdict pass

The perturbation was removed and the same pair re-run: 23P/0F on both sides, no failures in any
set. So the red verdict tracks the perturbation, not the environment.

## What this does and does not establish

Establishes: a test that fails only under solx is detected, attributed to solx, named, and
re-run, on this scenario and runner.

Does not establish: that any suite in this evaluation would notice a wrong-value miscompilation.
That depends on the suites' own assertions, which were never measured for coverage.

## Reproducing

    cd <clone>/ens-verifiable-factory-solx && git apply perturbation.patch
    node scripts/benchmark/test-under-solx.ts \
      --scenario ./end-to-end/ens-verifiable-factory-solx --runner solidity \
      --pair solx-0.1.7:default --no-init \
      --e2e-clone-dir <clone-dir> --out <evidence-dir>
    cd <clone>/ens-verifiable-factory-solx && git checkout -- test/UUPSProxy.t.sol

Both runs used the harness with the stricter verdict logic: a solx test count below 90% of the
control's is a `harness-failures` verdict, and a compile-error pattern in a green run's log is
recorded on the pair record. The sweep's 18 rows predate that logic.
