# solx test-execution evaluation — running matrix

solx pin: 0.1.7. Legend: P/F/S = passing/failing/skipped.

| scenario | runner | pair | verdict | solx | control | solx-only | both | EIP-170 | flaky |
|---|---|---|---|---|---|--:|--:|--:|--:|
| ens-verifiable-factory-solx | solidity | solx-0.1.7 vs default | **test-failures** | 23P/1F/0S | 24P/0F/0S | 1 | 0 | 0 | 0 |

## Details

### ens-verifiable-factory-solx / solidity / solx-0.1.7-vs-default

1 test(s) fail under solx but pass under the solc control

solx-only failures:

- `UUPSProxyTest#test_PositiveControl_SolcRuntimeLength()` (reproduced)