# solx test-execution evaluation — running matrix

solx pin: 0.1.7. Legend: P/F/S = passing/failing/skipped.

| scenario | runner | pair | verdict | solx | control | solx-only | both | EIP-170 | flaky |
|---|---|---|---|---|---|--:|--:|--:|--:|
| ens-verifiable-factory-solx | solidity | solx-0.1.7 vs default | **pass** | 23P/0F/0S | 23P/0F/0S | 0 | 0 | 0 | 0 |